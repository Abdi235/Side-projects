declare module "*.png";
declare module "*.svg";
